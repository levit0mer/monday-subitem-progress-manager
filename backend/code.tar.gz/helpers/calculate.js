const { progress } = require('./progress');

// Helper function to calculate progress based on subitem statuses
const calculateParentItemProgress = () => {
    // TODO: Implement logic before returning progress
    return progress(subitems, weights)
  };
  
module.exports = { printLog1 };
  